
Exercise 1 - Homepage and Music

=== Infomation===

Name: Gal Elfersy
ID: 3158500083
User Name: galel

Link for the all files: https://galel.mysoft.jce.ac.il/
Link for the Website: https://galel.mysoft.jce.ac.il/HomePage.html
Link for the Ex1 files: https://galel.mysoft.jce.ac.il/Ex1/

===Description ===

Attached files:
HomePage.html
HomePage.css
HomePage.js
pic.jpeg
music_list.php
get_current_date.php
README_galel.txt

Program explanation:
In this exercise, we created a website that displays personal information and a list of songs that we loved.
The information about the songs and the song is uploaded to the site by Ajax call.

תשובה לשאלה 6:
1) 
השרת טוען את ספריית הJQuery והAjax, את קובץ הCSS, קובץ הJS, קבצי הPHP ואת התמונה.
לאחר שהקבצים נטענו בדף הHTML, הקריאות מתבצעות והקבצים מתחילים לפעול.
תחילה, יש טעינה של הCSS והפעלת עיצוב הדף, לאחר מכן מתחיל טעינה של קובץ הPHP לקבלת התאריך,
לבסוף, קובץ הJS שמכיל את הפוקנציות ומבצע את הפעולות בהתאם ללחיצה,
תחילה לחיצה על כפתור של רשימת השירים, יטען את רשימת השירים ולאחר מכן יצור טבלה עם רשימת השירים והכפתורים,
לבסוף לאחר לחיצה על כל כפתור play יטען השיר עצמו לאתר ואז יוצג למשתמש.

2) 
הבקשות הן HomePage.html, HomePage.css, HomePage.js, ספריית JQurey וAjax, קובץ התמונה pic.jpeg, וקבצי הPHP.
סוגי ההדרים:
HomePage.html הינו מסמך
HomePage.css הינו קובץ עיצוב
HomePage.js, ספריית JQurey וAjax וקבצי הPHP הינם סקריפטים
pic.jpeg הינו קובץ תמונה
מי מפעיל את ההדר:
HomePage.html פועל בהתאם לפעולת המשתמש
HomePage.css, pic.jpeg, HomePage.js פועל בהתאם לקובץ הHTML
ספריית JQurey וAjax פועלת בהתאם לספרייה
קבצי הPHP בהתאם לקריאות בקובץ הJS

